package joptionpane;

import javax.swing.JOptionPane;

public class Repaso2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Su ordenador tiene un Ransomware", "Error grave",
				JOptionPane.INFORMATION_MESSAGE);
	}

}
