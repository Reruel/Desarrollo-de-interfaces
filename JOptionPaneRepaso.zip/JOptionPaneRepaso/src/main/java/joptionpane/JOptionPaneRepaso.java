package joptionpane;

import javax.swing.JOptionPane;

public class JOptionPaneRepaso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre = "Reyes";
		JOptionPane.showMessageDialog(null, "Bienvenida, " + nombre);
	}

}
