module T5Interfaces2 {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	
	opens ej1 to javafx.graphics, javafx.fxml;
	opens ej2 to javafx.graphics, javafx.fxml;
	opens ej3 to javafx.graphics, javafx.fxml;
	opens ej4y5 to javafx.graphics, javafx.fxml;
	opens ej6y7 to javafx.graphics, javafx.fxml;
	
}
