package ejercicio3;

import javafx.event.*;
import javafx.fxml.*;

public class Controller3 {
	@FXML
	private void pulsame(ActionEvent event) {
		System.out.println("¡Ha pulsado el botón!");
	}
}