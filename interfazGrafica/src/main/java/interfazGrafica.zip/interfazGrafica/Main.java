package interfazGrafica;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Mi primera ventana");
		ventana.setSize(400,400);
		ventana.setVisible(true);
		
		
		
		/*JFrame ventana=new JFrame("primera ventana");
		ventana.setSize(400,400);
		ventana.setVisible(true);*/
	}

}
